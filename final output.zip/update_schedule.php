<?php
include 'db.php';

// Check if 'id' is passed
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('Schedule ID is missing!'); window.location='schedules_list.php';</script>";
    exit();
}

$schedule_id = intval($_GET['id']);

// Fetch schedule info
$stmt = $connect->prepare("SELECT * FROM schedules WHERE schedule_id = ?");
$stmt->bind_param("i", $schedule_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<script>alert('Schedule not found!'); window.location='schedules_list.php';</script>";
    exit();
}

$schedule = $result->fetch_assoc();
$stmt->close();

// Fetch all movies for the dropdown
$movies_result = $connect->query("SELECT * FROM movies ORDER BY title ASC");

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movie_id = isset($_POST['movie_id']) ? intval($_POST['movie_id']) : 0;
    $show_date = isset($_POST['show_date']) ? $_POST['show_date'] : '';
    $show_time = isset($_POST['show_time']) ? $_POST['show_time'] : '';

    if ($movie_id <= 0 || empty($show_date) || empty($show_time)) {
        echo "<script>alert('All fields are required!'); window.history.back();</script>";
        exit();
    }

    $update_stmt = $connect->prepare("UPDATE schedules SET movie_id=?, show_date=?, show_time=? WHERE schedule_id=?");
    $update_stmt->bind_param("issi", $movie_id, $show_date, $show_time, $schedule_id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Schedule updated successfully!'); window.location='schedules_list.php';</script>";
    } else {
        echo "<script>alert('Failed to update schedule: ".$update_stmt->error."'); window.history.back();</script>";
    }

    $update_stmt->close();
    $connect->close();
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Schedule - Cinema Management System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #111;
            font-family: Arial, sans-serif;
            color: white;
        }

        header {
            background: #e50914;
            padding: 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 2px;
        }

        .container {
            width: 90%;
            max-width: 500px;
            margin: 50px auto;
            background: #1c1c1c;
            padding: 30px;
            border-radius: 15px;
            border: 2px solid #333;
            box-shadow: 0 0 20px rgba(0,0,0,0.5);
        }

        h1 {
            text-align: center;
            text-transform: uppercase;
            margin-bottom: 20px;
            border-bottom: 2px solid #e50914;
            padding-bottom: 10px;
        }

        form select,
        form input[type="date"],
        form input[type="time"],
        form button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #333;
            background: #222;
            color: white;
            font-size: 16px;
        }

        form button {
            background: #e50914;
            border: none;
            cursor: pointer;
            transition: 0.3s;
        }

        form button:hover {
            background: #ff1a1a;
        }

        .btn-back {
            display: inline-block;
            margin-bottom: 15px;
            padding: 10px 20px;
            background: #1a73e8;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            transition: 0.3s;
        }

        .btn-back:hover {
            background: #4285f4;
        }

        footer {
            margin-top: 50px;
            text-align: center;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>

<header>🎬 CINEMA MANAGEMENT SYSTEM</header>

<div class="container">
    <a href="schedules_list.php" class="btn-back">← Back to Schedules</a>
    <h1>Update Schedule</h1>

    <form method="POST" action="">
        <label for="movie_id">Select Movie:</label>
        <select name="movie_id" id="movie_id" required>
            <option value="">-- Choose a movie --</option>
            <?php while ($movie = $movies_result->fetch_assoc()) { ?>
                <option value="<?= $movie['movie_id'] ?>" <?= $movie['movie_id'] == $schedule['movie_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($movie['title']) ?>
                </option>
            <?php } ?>
        </select>

        <label for="show_date">Show Date:</label>
        <input type="date" name="show_date" id="show_date" value="<?= $schedule['show_date'] ?>" required>

        <label for="show_time">Show Time:</label>
        <input type="time" name="show_time" id="show_time" value="<?= $schedule['show_time'] ?>" required>

        <button type="submit">Update Schedule</button>
    </form>
</div>

<footer>© <?= date("Y") ?> Cinema Management System</footer>

</body>
</html>
