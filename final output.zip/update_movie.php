<?php
include 'db.php';

// Check if the connection variable ($connect) is defined and valid
if (!isset($connect) || $connect->connect_error) {
    error_log("DB Connection failed in update_movie.php");
    echo "<script>alert('Critical Database Connection Error!'); window.location='movies_list.php';</script>";
    exit();
}

// Validate ID from GET
$movie_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if($movie_id <= 0){
    // Using a simple modal box for feedback as requested
    echo "<script>alert('Invalid Movie ID! Please provide a valid movie ID.'); window.location='movies_list.php';</script>";
    exit();
}

// Fetch movie
$stmt = $connect->prepare("SELECT * FROM movies WHERE movie_id=?");
if ($stmt === false) {
    // Handle error if the statement preparation fails
    error_log("Prepare failed: " . $connect->error);
    echo "<script>alert('Database error during movie fetch (Prepare failed)!'); window.location='movies_list.php';</script>";
    exit();
}

$stmt->bind_param("i", $movie_id);
if (!$stmt->execute()) {
    // Handle error if execution fails
    error_log("Execute failed: " . $stmt->error);
    echo "<script>alert('Database error during movie fetch (Execute failed)!'); window.location='movies_list.php';</script>";
    exit();
}
$result = $stmt->get_result();

if($result->num_rows === 0){
    echo "<script>alert('Movie not found!'); window.location='movies_list.php';</script>";
    exit();
}

$movie = $result->fetch_assoc();
$stmt->close();
// We will close the connection after the HTML is rendered to ensure all PHP code runs.
// The $connect->close() call is removed from here.
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Movie - Cinema Management System</title>
    <style>
        body { margin:0; padding:0; background:#111; font-family:Arial,sans-serif; color:white; }
        header { background:#e50914; padding:20px; text-align:center; font-size:32px; font-weight:bold; }
        .container { width:90%; max-width:500px; margin:50px auto; background:#1c1c1c; padding:30px; border-radius:15px; border:2px solid #333; }
        h1 { text-align:center; margin-bottom:20px; border-bottom:2px solid #e50914; padding-bottom:10px; }
        form input, form select { width:100%; padding:10px; margin:10px 0; border-radius:8px; border:1px solid #333; background:#222; color:white; font-size:16px; }
        form button { width:100%; padding:12px; margin-top:15px; border:none; border-radius:10px; background:#e50914; color:white; font-size:18px; cursor:pointer; }
        form button:hover { background:#ff1a1a; }
        a.home-btn { display:block; text-align:center; margin-top:15px; color:#1a73e8; text-decoration:none; }
        a.home-btn:hover { text-decoration:underline; }
        footer { margin-top:50px; text-align:center; font-size:14px; color:#777; }
    </style>
</head>
<body>

<header>🎬 CINEMA MANAGEMENT SYSTEM</header>

<div class="container">
    <h1>Update Movie</h1>

    <form action="update_movie_process.php" method="POST">
        <input type="hidden" name="id" value="<?= $movie['movie_id'] ?>">
        <input type="text" name="title" placeholder="Movie Title" value="<?= htmlspecialchars($movie['title']) ?>" required>
        
        <select name="genre" required>
            <!-- Note: It's better to fetch available genres from a table if possible, 
                 but using hardcoded options based on your example -->
            <option value="Action" <?= $movie['genre']=='Action' ? 'selected':'' ?>>Action</option>
            <option value="Drama" <?= $movie['genre']=='Drama' ? 'selected':'' ?>>Drama</option>
            <option value="Horror" <?= $movie['genre']=='Horror' ? 'selected':'' ?>>Horror</option>
            <option value="Comedy" <?= $movie['genre']=='Comedy' ? 'selected':'' ?>>Comedy</option>
            <option value="Romance" <?= $movie['genre']=='Romance' ? 'selected':'' ?>>Romance</option>
            <!-- Add more genres if necessary -->
            <option value="Sci-Fi" <?= $movie['genre']=='Sci-Fi' ? 'selected':'' ?>>Sci-Fi</option>
            <option value="Crime" <?= $movie['genre']=='Crime' ? 'selected':'' ?>>Crime</option>
            <option value="Fiction" <?= $movie['genre']=='Fiction' ? 'selected':'' ?>>Fiction</option>

        </select>
        <input type="number" name="duration" placeholder="Duration (minutes)" value="<?= $movie['duration'] ?>" required>
        <input type="number" step="0.01" name="price" placeholder="Price" value="<?= $movie['price'] ?>" required>
        <button type="submit">Update Movie</button>
    </form>

    <a class="home-btn" href="movies_list.php">🏠 Back to Movies List</a>
</div>

<footer>© <?= date("Y") ?> Cinema Management System</footer>

</body>
</html>

<?php
// Close the connection once the rest of the script (HTML) has been served
if (isset($connect)) {
    $connect->close();
}
?>