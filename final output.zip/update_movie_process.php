<?php
include(__DIR__ . '/db.php'); // make sure db.php is in the same folder

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Sanitize and get POST data
    $id       = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $title    = isset($_POST['title']) ? trim($_POST['title']) : '';
    $genre    = isset($_POST['genre']) ? trim($_POST['genre']) : '';
    $duration = isset($_POST['duration']) ? intval($_POST['duration']) : 0;
    $price    = isset($_POST['price']) ? floatval($_POST['price']) : 0;

    // Validate all fields
    if (empty($id) || empty($title) || empty($genre) || empty($duration) || empty($price)) {
        echo "<script>alert('All fields are required!'); window.history.back();</script>";
        exit();
    }

    // Prepare the update statement
    $stmt = $connect->prepare("UPDATE movies SET title=?, genre=?, duration=?, price=? WHERE movie_id=?");

    if (!$stmt) {
        die("Prepare failed: " . $connect->error);
    }

    // Bind parameters (ssidi = string, string, integer, double, integer)
    $stmt->bind_param("ssidi", $title, $genre, $duration, $price, $id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script>alert('Movie updated successfully!'); window.location='movies_list.php';</script>";
    } else {
        echo "<script>alert('Failed to update movie: " . $stmt->error . "'); window.history.back();</script>";
    }

    // Close statement and connection
    $stmt->close();
    $connect->close();

} else {
    // Redirect if accessed directly
    header("Location: movies_list.php");
    exit();
}
?>
