<?php
include 'db.php';

$search = '';
$results = [];

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);

    // Fetch movies matching search
    $stmt = $connect->prepare("SELECT * FROM movies WHERE title LIKE ? OR genre LIKE ? ORDER BY title ASC");
    $param = "%" . $search . "%";
    $stmt->bind_param("ss", $param, $param);
    $stmt->execute();
    $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Fetch schedules for these movies
    $movie_ids = array_column($results, 'movie_id');
    if (!empty($movie_ids)) {
        $ids_placeholder = implode(',', array_fill(0, count($movie_ids), '?'));
        $types = str_repeat('i', count($movie_ids));
        $stmt_schedules = $connect->prepare("SELECT * FROM schedules WHERE movie_id IN ($ids_placeholder) ORDER BY show_date, show_time ASC");
        $stmt_schedules->bind_param($types, ...$movie_ids);
        $stmt_schedules->execute();
        $schedules_result = $stmt_schedules->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt_schedules->close();

        // Group schedules by movie_id
        $schedules_by_movie = [];
        foreach ($schedules_result as $s) {
            $schedules_by_movie[$s['movie_id']][] = $s;
        }
    }
}

$connect->close();
?>

<!DOCTYPE html>

<html>
<head>
    <title>Inquire Movie - Cinema Management System</title>
    <style>
        body {margin:0; padding:0; background:#111; color:white; font-family:Arial,sans-serif;}
        header {background:#e50914; padding:20px; text-align:center; font-size:32px; font-weight:bold;}
        .container {width:90%; max-width:900px; margin:40px auto; background:#1c1c1c; padding:20px; border-radius:10px;}
        h2 {text-align:center; margin-bottom:20px; color:#e50914;}
        form input[type="text"], form button {width:100%; padding:10px; margin-bottom:15px; border-radius:5px; border:none; font-size:16px;}
        input[type="text"] {background:#333; color:white;}
        button {background:#e50914; color:white; cursor:pointer; transition:0.3s;}
        button:hover {background:#ff1a1a;}
        table {width:100%; border-collapse:collapse; margin-top:20px;}
        th, td {padding:10px; border-bottom:1px solid #444; text-align:left;}
        th {background:#222;}
        .schedules {margin-left:20px; margin-top:5px;}
        .schedule-item {padding:5px 0; border-bottom:1px solid #333;}
        a.home-btn {display:block; margin-top:20px; text-align:center; color:#1a73e8; text-decoration:none;}
        a.home-btn:hover {text-decoration:underline;}
    </style>
</head>
<body>

<header>🎬 CINEMA MANAGEMENT SYSTEM</header>

<div class="container">
    <h2>Inquire Movie</h2>

```
<form method="GET" action="">
    <input type="text" name="search" placeholder="Enter movie title or genre..." value="<?= htmlspecialchars($search) ?>" required>
    <button type="submit">Search</button>
</form>

<?php if (!empty($results)): ?>
    <table>
        <tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Duration (min)</th>
            <th>Price ($)</th>
            <th>Schedules</th>
        </tr>
        <?php foreach ($results as $movie): ?>
            <tr>
                <td><?= htmlspecialchars($movie['title']) ?></td>
                <td><?= htmlspecialchars($movie['genre']) ?></td>
                <td><?= htmlspecialchars($movie['duration']) ?></td>
                <td><?= number_format($movie['price'], 2) ?></td>
                <td>
                    <div class="schedules">
                    <?php if (!empty($schedules_by_movie[$movie['movie_id']])): ?>
                        <?php foreach ($schedules_by_movie[$movie['movie_id']] as $s): 
                            $dateObj = new DateTime($s['show_date'] . ' ' . $s['show_time']);
                            echo '<div class="schedule-item">' . $dateObj->format('D, d/m/Y \a\t H:i') . '</div>';
                        endforeach; ?>
                    <?php else: ?>
                        <div class="schedule-item">No schedules</div>
                    <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php elseif($search !== ''): ?>
    <p>No movies found matching "<?= htmlspecialchars($search) ?>".</p>
<?php endif; ?>

<a class="home-btn" href="index.php">🏠 Back to Home</a>
```

</div>

</body>
</html>
