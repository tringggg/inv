<?php
include 'db.php';

// Check if 'id' is passed
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('Schedule ID is missing!'); window.location='schedules_list.php';</script>";
    exit();
}

$schedule_id = intval($_GET['id']); // sanitize input

// Prepare and execute delete statement
$stmt = $connect->prepare("DELETE FROM schedules WHERE schedule_id=?");
$stmt->bind_param("i", $schedule_id);

if ($stmt->execute()) {
    echo "<script>alert('Schedule deleted successfully!'); window.location='schedules_list.php';</script>";
} else {
    echo "<script>alert('Failed to delete schedule: ".$stmt->error."'); window.location='schedules_list.php';</script>";
}

$stmt->close();
$connect->close();
?>
