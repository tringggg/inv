<?php
include 'db.php';

// Fetch all movies
$result = $connect->query("SELECT * FROM movies ORDER BY movie_id ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Movies List - Cinema Management System</title>
    <style>
        body { margin:0; padding:0; background:#111; font-family:Arial,sans-serif; color:white; }
        header { background:#e50914; padding:20px; text-align:center; font-size:32px; font-weight:bold; }
        .container { width:90%; max-width:1000px; margin:40px auto; }
        table { width:100%; border-collapse:collapse; background:#1c1c1c; border-radius:10px; overflow:hidden; }
        th, td { padding:12px; text-align:center; border-bottom:1px solid #333; }
        th { background:#e50914; }
        tr:hover { background:#333; }
        a { text-decoration:none; color:white; padding:5px 10px; border-radius:5px; }
        .btn-edit { background:#ffc107; }
        .btn-delete { background:#dc3545; }
        .btn-info { background:#1a73e8; }
        .btn-edit:hover { background:#ffca2c; }
        .btn-delete:hover { background:#ff4d4d; }
        .btn-info:hover { background:#4285f4; }
        .top-actions { margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; }
        .btn-add { background:#1a73e8; padding:10px 20px; border-radius:8px; }
        .btn-add:hover { background:#4285f4; }
        .btn-home { background:#e50914; padding:10px 20px; border-radius:8px; margin-left:10px; }
        .btn-home:hover { background:#ff1a1a; }
        footer { margin-top:50px; text-align:center; color:#777; font-size:14px; }
    </style>
</head>
<body>

<header>🎬 CINEMA MANAGEMENT SYSTEM</header>

<div class="container">
    <div class="top-actions">
        <h2>Movies List</h2>
        <div>
            <a href="add_movie.php" class="btn-add">+ Add New Movie</a>
            <a href="index.php" class="btn-home">🏠 Home</a>
        </div>
    </div>

    <table>
        <tr>
            <th>ID</th><th>Title</th><th>Genre</th><th>Duration (min)</th><th>Price ($)</th><th>Actions</th>
        </tr>
        <?php if($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['movie_id'] ?></td>
                    <td><?= htmlspecialchars($row['title']) ?></td>
                    <td><?= htmlspecialchars($row['genre']) ?></td>
                    <td><?= $row['duration'] ?></td>
                    <td><?= number_format($row['price'], 2) ?></td>
                    <td>
                        <a class="btn-info" href="inquire_movie.php?id=<?= $row['movie_id'] ?>">Info</a>
                        <a class="btn-edit" href="update_movie.php?id=<?= $row['movie_id'] ?>">Edit</a>
                        <a class="btn-delete" href="delete_movie.php?id=<?= $row['movie_id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">No movies found.</td></tr>
        <?php endif; ?>
    </table>
</div>

<footer>© <?= date("Y") ?> Cinema Management System</footer>

</body>
</html>
