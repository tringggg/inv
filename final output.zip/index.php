<!DOCTYPE html>
<html>
<head>
    <title>Cinema Management System</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            background: #111;
            font-family: Arial, sans-serif;
            color: white;
        }

        header {
            background: #e50914;
            padding: 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 2px;
        }

        .container {
            width: 90%;
            max-width: 900px;
            margin: 40px auto;
            text-align: center;
        }

        .section-title {
            font-size: 26px;
            margin-bottom: 20px;
            text-transform: uppercase;
            border-bottom: 2px solid #e50914;
            padding-bottom: 10px;
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-gap: 20px;
            margin-top: 30px;
        }

        .menu-item {
            background: #1c1c1c;
            padding: 25px;
            border-radius: 15px;
            transition: 0.3s;
            font-size: 20px;
            border: 2px solid #333;
        }

        .menu-item:hover {
            background: #e50914;
            transform: translateY(-5px);
            cursor: pointer;
        }

        a {
            text-decoration: none;
            color: white;
            display: block;
        }

        footer {
            margin-top: 50px;
            text-align: center;
            color: #777;
            font-size: 14px;
        }

    </style>
</head>
<body>

<header>
    🎬 CINEMA MANAGEMENT SYSTEM
</header>

<div class="container">

    <div class="section-title">Movie Controls</div>

    <div class="menu-grid">
        <a href="add_movie.php"><div class="menu-item">➕ Add Movie</div></a>
        <a href="movies_list.php"><div class="menu-item">📋 List of Movies</div></a>
        <a href="inquire_movie.php"><div class="menu-item">🔍 Inquire Movie</div></a>
    
    </div>

    <div class="section-title" style="margin-top: 50px;">Schedules</div>

    <div class="menu-grid">
        <a href="add_schedule.php"><div class="menu-item">🕒 Add Schedule</div></a>
        <a href="schedule_list.php"><div class="menu-item">📆 Schedule List</div></a>
    </div>

    <div class="section-title" style="margin-top: 50px;">Reservations</div>

    

	<div class="menu-grid">
    <a href="add_reservation.php"><div class="menu-item">➕ Add Reservation</div></a>
    <a href="reservation_list.php"><div class="menu-item">🪑 View Reservations</div></a>
    <a href="transaction_history.php"><div class="menu-item">📜 Transaction History</div></a>
</div>

</div>

<footer>
    © <?= date("Y") ?> Cinema Management System — All Rights Reserved.
</footer>

</body>
</html>
