<?php
include 'db.php';

// Get POST data and sanitize
$title    = isset($_POST['title']) ? trim($_POST['title']) : '';
$genre    = isset($_POST['genre']) ? trim($_POST['genre']) : '';
$duration = isset($_POST['duration']) ? intval($_POST['duration']) : 0;
$price    = isset($_POST['price']) ? floatval($_POST['price']) : 0;

// Validate required fields
if (empty($title) || empty($genre) || empty($duration) || empty($price)) {
    echo "<script>alert('All fields are required!'); window.history.back();</script>";
    exit();
}

// Prepare the INSERT statement
$stmt = $connect->prepare("INSERT INTO movies (title, genre, duration, price) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssid", $title, $genre, $duration, $price);

// Execute and check
$success = $stmt->execute();

$stmt->close();
$connect->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Movie Added</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #111;
            font-family: Arial, sans-serif;
            color: white;
            text-align: center;
        }

        header {
            background: #e50914;
            padding: 20px;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 2px;
        }

        .container {
            width: 90%;
            max-width: 500px;
            margin: 60px auto;
            background: #1c1c1c;
            padding: 30px;
            border-radius: 15px;
            border: 2px solid #333;
        }

        h2 {
            margin-bottom: 20px;
            text-transform: uppercase;
            border-bottom: 2px solid #e50914;
            padding-bottom: 10px;
        }

        .message {
            font-size: 18px;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            border-radius: 10px;
            background: #e50914;
            color: white;
            font-size: 16px;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn:hover {
            background: #ff1a1a;
        }

        footer {
            margin-top: 50px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>

<header>🎬 CINEMA MANAGEMENT SYSTEM</header>

<div class="container">
    <h2>Movie Added</h2>

    <?php if ($success): ?>
        <div class="message">Movie "<strong><?= htmlspecialchars($title) ?></strong>" has been added successfully!</div>
        <a href="movies_list.php" class="btn">View Movies</a>
    <?php else: ?>
        <div class="message">Failed to add movie. Please try again.</div>
        <a href="add_movie.php" class="btn">Back to Add Movie</a>
    <?php endif; ?>
</div>

<footer>© <?= date("Y") ?> Cinema Management System</footer>

</body>
</html>
