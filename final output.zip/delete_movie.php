<?php
include 'db.php';
$id = $_GET['id'];

$connect->query("DELETE FROM movies WHERE movie_id = $id");

header("Location: movies_list.php");
?>
